const title = document.querySelector("#title");
title.innerHTML = "Hi From JS";
title.style.color = 'red';
document.title = "i own you now0";
console.dir(document);

function sayHello(name, age){
  //console.log(`Hello ${name} you are ${age} years old`);
  return `Hello ${name} you are ${age} years old`;
}

const greetBan = sayHello("ban",15);

//console.log (greetBan);

const calculator = {
 plus : function (a,b){
   return a + b;
 } ,
 square : function (a,b) {
   return a**b;
 },
 minus : function (a,b){
   return a-b;
 },
 division: function (a,b){
   return  a/b;
 }
 
}
